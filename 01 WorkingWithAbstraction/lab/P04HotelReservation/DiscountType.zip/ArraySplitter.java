package P04HotelReservation;

public class ArraySplitter {
    public static String[] makeArray(String data){
        return data.split("\\s+");
    }
}
